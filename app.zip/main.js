var starter = angular.module('starter', ['ui.router']);
var CONTACTS_END_POINT = 'http://jsonplaceholder.typicode.com/users';

starter.config(function($stateProvider, $urlRouterProvider) {
    //
    // For any unmatched url, redirect to /home
    $urlRouterProvider.otherwise("/list");
    //
    // Now set up the states
    $stateProvider
        .state('list', {
            url: "/list",
            templateUrl: "rwtest/users/partials/users-list.tpl.html",
            controller: 'ContactController'
        })
        .state('profile', {
            url: "/profile/:id",
            templateUrl: "rwtest/profile/partials/user-profile.tpl.html",
            controller: 'ProfileController'
        });

});
starter.service('ContactsService', function($http, $q) {

    var ContactsService = this;

    return {
        getContacts: getContacts
    }


    function getContacts() {
        ContactsService.contacts = [];
        var deferred = $q.defer();

        $http.get(CONTACTS_END_POINT)
            .then(function(res) {
                //console.log(res);
                while (res.data[0]) {
                    ContactsService.contacts.push(res.data.pop());
                }
                deferred.resolve(ContactsService.contacts);
            }, function(error) {
                console.log('Express service returned 0 contacts');
                deferred.reject(error);
            });
        return deferred.promise;
    }

});


starter.controller('ContactController', function($scope, $state, ContactsService) {
    $scope.contacts = [];
    ContactsService.getContacts().then(function(success) {
        $scope.contacts = success;
    }, function(error) {
        console.log(error);
    });


    $scope.goToProfile = function(userId) {
        $state.go('profile', { id: userId });
    }
});

starter.controller('ProfileController', function($scope, $state, $stateParams, ContactsService) {
    ContactsService.getContacts().then(function(contacts) {
        // $scope.profile = contacts[$stateParams.id];

        angular.forEach(contacts, function(user, key) {
            if (user.id === parseInt($stateParams.id)) {
                console.log(user);
                $scope.profile = user;
            }
        });
    }, function(error) {
        console.log(error);
    });

    $scope.goToUserListPage = function(userId) {
        $state.go('list');
    };
});

starter.filter('camelCase', function() {
    return function(name) {
        var type = typeof name;
        if (type !== 'string' && type !== 'number') throw new Error();
        return name.toString().split(" ").map(function(word) {
            return word[0].toUpperCase().concat(word.slice(1));
        }).join(" ");
    };
});

starter.directive('avatar', function() {

    return {
        scope: {
            name: '=',
        },
        restrict: 'AE',
        template: "<span class='avatar'>{{name[0] | camelCase}}</span>",
    };
});
